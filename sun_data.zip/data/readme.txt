
--------------------------------------------------------------------------------------------
              storage   display    value
variable name   type    format     label      variable label
--------------------------------------------------------------------------------------------
sessionid       str8    %9s                   unique session ID
period          byte    %8.0g                 Period 1-80
subject         byte    %8.0g                 Subject ID (unique in each session)
group           byte    %8.0g                 Group ID (unique in each session)
pubsignal       byte    %8.0g                 Public signal 0/100 in Treatments C, CC, and CP
privsignal      int     %8.0g                 Private signal 0/100 in Treatments P75, P95, AC, and CP. In Treatment CC privsignal refers to the second public signal.
state           byte    %8.0g                 State of the world Z = 0 or Z=100
decision        byte    %8.0g                 Own decision
payoff          float   %8.0g                 Own payoff
otherdecision   byte    %8.0g                 Decision of interaction partner
treatment       float   %9.0g      			  Treatment ID


Notes: Group ID identifies each pair of players in each round. In each session six subjects form a matching group. That is, subjects 1-6 constitute a matching group, subjects 7-12 another matching group, and so on. Subjects are randomly rematched into pairs in each round within a matching group. 
